<?php
include "app/code/autoload.php";
include "app/Sdp.php";
Sdp::run();
?>