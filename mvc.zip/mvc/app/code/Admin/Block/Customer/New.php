<?php

class Admin_Block_Customer_New extends Core_Block_Template{
    public function _contstruct(){

    }
   public function __construct(){
        $this->setTemplate("Admin\View\Customer/new.phtml");
   }
}
?>