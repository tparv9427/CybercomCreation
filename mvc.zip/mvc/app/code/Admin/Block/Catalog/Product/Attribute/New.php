<?php

class Admin_Block_Catalog_Product_Attribute_New extends Core_Block_Template{
    public function _contstruct(){

    }
   public function __construct(){
        $this->setTemplate("Admin\View\Catalog\Product\Attribute\New.phtml");
   }
}
?>