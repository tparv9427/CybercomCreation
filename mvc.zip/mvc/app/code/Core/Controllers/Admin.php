<?php
class Core_Controllers_Admin extends Core_Controllers_Front_Action{
 protected $_request;
}

?>