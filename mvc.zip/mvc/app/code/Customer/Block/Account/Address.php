<?php

class Customer_Block_Account_Address extends Core_Block_Template{
    public function _contstruct(){

    }
   public function __construct(){
        $this->setTemplate("Customer\View\Account\address.phtml");
   }
}
?>