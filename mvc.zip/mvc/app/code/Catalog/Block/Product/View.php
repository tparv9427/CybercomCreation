<?php

class Catalog_Block_Product_View extends Core_Block_Template{
    public function _contstruct(){

    }
   public function __construct(){
        $this->setTemplate("Catalog/View/Product/view.phtml");
   }
}
?>